#!/usr/bin/env python
# coding: utf-8

# In[6]:


import CarParkFunctions
class CarPark:               
    def __init__(self):                                      #Initializer Function/Default Variables
        self.maxspace = 0
        self.slotid = 0
        self.occupiedslots = 0
        
    def createPark(self,maxspace):                         #Input parameters for park design
        self.slots = [-1] * maxspace                       # -1 indicates empty slot, so initially all slots are -1(Empty)
        self.maxspace = maxspace
        return self.maxspace
    
    def getFirstEmptySlot(self):                           #returns the first slot with -1 value as -1 indicates empty
        for i in range(len(self.slots)):    
            if self.slots[i] == -1:
                return i
    
    def parkcar(self,regno,color):
        if self.occupiedslots < self.maxspace:             #Check if parking slot is not full
            slotid = self.getFirstEmptySlot()              #Get the first empty slot number
            self.slots[slotid] = CarParkFunctions.Car(regno,color)    #Get the details of the car to be parked
            self.slotid = self.slotid+1                    #Increment SlotID by 1 to indicate current slot is full  
            self.occupiedslots = self.occupiedslots + 1    #Count of occupied slots increase by one after successful car park
            return slotid+1
        else:
            return -1
        
    def OutCar(self,slotid):
        if self.occupiedslots > 0 and self.slots[slotid-1] != -1: #Check if there is atleast 1 parked car
            self.slots[slotid-1] = -1                             #Remove the car from current slot
            self.occupiedslots = self.occupiedslots - 1           #Decrease value of occupied slots by 1
            return slotid
        else:
            return False
        
    def getSlotNoFromRegNo(self,regno):                     #To get the value of the slot number from regNo of parked car
        for i in range(len(self.slots)):
            if self.slots[i].regno == regno:
                return i+1
            else:
                continue
        return -1
    
    def PrintParkDetails(self):                             #Get info of all the slots in the park
        print("Slot No.\tRegistration No.\tColour")
        for i in range(len(self.slots)):
            if self.slots[i] != -1:
                print(str(i+1) + "\t\t\t" +str(self.slots[i].regno) + "\t\t\t\t" + str(self.slots[i].color))
            else:
                continue
                
    def CallFun(self,FunName):                             #Call the required function of the class
        if FunName.startswith('Create'):
            n = int(FunName.split(' ')[1])
            space = self.createPark(n)
            print('Parking lot has been created with '+str(space)+' slots')

        elif FunName.startswith('Park'):
            regno = FunName.split(' ')[1]
            color = FunName.split(' ')[2]
            space = self.parkcar(regno,color)
            if space == -1:
                print("Sorry, Parking is full !!")
            else:
                print('Car parked at slot number: '+str(space))

        elif FunName.startswith('Out'):
            OutCar_slotid = int(FunName.split(' ')[1])
            status = self.OutCar(OutCar_slotid)
            if status:
                print('Car from Slot number '+str(status)+' left and the slot is free now')

        elif FunName.startswith('Details'):
            self.PrintParkDetails()
            
        else:
            exit(0)
            
def main():
    carpark = CarPark()                           #Create Object of Class
    print("\nAvailable functions: \n"
          "Create\n"
          "Park\n"
          "Out\n"
          "Details\n")
    while True:
        FunName = input("Which function do you want to perform :- ") #User input on which function is to be performed
        carpark.CallFun(FunName)              #Call Function Caller

if __name__ == '__main__':
    main()
