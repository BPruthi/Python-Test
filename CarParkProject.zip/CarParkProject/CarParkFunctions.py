#!/usr/bin/env python
# coding: utf-8

# In[1]:


class CarParkFunctions:
    def __init__(self,regno,color):
        self.color = color
        self.regno = regno

class Car(CarParkFunctions):
    def __init__(self,regno,color):
        CarParkFunctions.__init__(self,regno,color)

